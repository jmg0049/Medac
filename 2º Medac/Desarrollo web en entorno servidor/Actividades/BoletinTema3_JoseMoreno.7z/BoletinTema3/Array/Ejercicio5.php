<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 5</title>
</head>
<body>
    <h1>Eliminar duplicados</h1>
    <?php
$datos= array(
    "nombre" => "GAbriel",
    "correo" => "Gabriel@hotmail.com",
    "telefono" => "12345678"
);

echo "Nombre: " . $datosDeContacto["nombre"] . "<br>";
echo "Correo electrónico: " . $datosDeContacto["correo"] . "<br>";
echo "Teléfono: " . $datosDeContacto["telefono"];
?>


</body>
</html>