<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>
<body>
    <h1>Encontrar el numero mas grande</h1>
    <?php
$Array = array(12, 45, 7, 98, 23, 56);
$numeroMasGrande = max($Array);
echo "El número más grande en el array es: " . $numeroMasGrande;
?>


</body>
</html>