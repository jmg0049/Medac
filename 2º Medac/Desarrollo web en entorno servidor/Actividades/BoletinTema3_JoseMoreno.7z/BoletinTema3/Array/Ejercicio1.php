<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 1</title>
</head>
<body>
    <h1>Sumar elementos de un array</h1>
    <?php

$Arraysuma = array(1, 2, 3, 4, 5);

$suma = array_sum($Arraysuma);


echo "La suma de los elementos del array es: " . $suma;
?>

</body>
</html>