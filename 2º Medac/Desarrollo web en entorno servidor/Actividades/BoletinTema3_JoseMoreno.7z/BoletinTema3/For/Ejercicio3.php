<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 3</title>
</head>
<body>
    <h1>Desarrolla un programa que utilice un bucle for para imprimir los números del 10 al 1
en orden descendente.</h1>
    <?php
        for ($i = 10; $i >= 1; $i--) {
            echo $i . " ";
        }
    ?>
</body>
</html>