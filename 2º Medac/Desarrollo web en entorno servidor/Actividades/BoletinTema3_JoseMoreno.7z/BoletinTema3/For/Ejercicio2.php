<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>
<body>
    <h1>Crea un bucle for que imprima los números pares del 2 al 20.</h1>
    <?php
        for ($i = 2; $i <= 20; $i += 2) {
            echo $i . " ";
        }
    ?>
</body>
</html>