<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 1</title>
</head>
<body>
    <h1>Escribe un bucle for que imprima los números del 1 al 10.</h1>
    <?php
        for ($i = 1; $i <= 10; $i++) {
            echo $i."<br>";
        }
    ?>
</body>
</html>