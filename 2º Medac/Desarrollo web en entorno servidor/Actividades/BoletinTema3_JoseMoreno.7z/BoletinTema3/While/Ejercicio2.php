<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>
<body>
    <h1>Crea un programa que imprima los números pares del 2 al 20 utilizando un bucle
while.</h1>
    <?php
       $i = 2;
       while ($i <= 20) {
           echo $i . " ";
           $i += 2;
       }
    ?>
</body>
</html>