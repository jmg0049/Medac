<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 1</title>
</head>
<body>
    <h1>Escribe un programa que imprima los números del 1 al 10 utilizando un bucle while.</h1>
    <?php
        $i = 1;
        while ($i <= 10) {
            echo $i . " ";
            $i++;
        }
    ?>
</body>
</html>