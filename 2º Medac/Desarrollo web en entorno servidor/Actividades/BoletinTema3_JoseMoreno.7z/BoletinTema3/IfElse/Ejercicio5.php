<html>
    <?php
    $numero1 = 19;
    $numero2 = 7;
    $numero3 = 10;
    
    $puntuacion = 59;

    if ($puntuacion >= 60) {
        echo "El estudiante ha aprobado el examen.";
    } else {
        echo "El estudiante ha reprobado el examen.";
    }
   ?>
</html>