<html>
    <?php
    $numero1 = 10;
    $numero2 = 5;
    if ($numero1>$numero2){
        echo "el numero 1 es mayor";
    }elseif ($numero1<$numero2){
        echo "el numero 1 es menor";
    }
    ?>
</html>