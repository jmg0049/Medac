<html>
    <?php
   $numero = 19;

   if ($numero > 0) {
       echo "El número " .$numero. " es positivo";
   } elseif ($numero < 0) {
       echo "El número " .$numero. " es negativo";
   } else {
       echo "El número " .$numero. " es cero";
   }
   ?>
</html>