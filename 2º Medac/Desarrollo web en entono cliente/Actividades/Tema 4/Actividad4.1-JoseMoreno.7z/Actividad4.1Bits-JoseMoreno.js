var operacion1 = 125 >> 3;
document.write("125 / 8 =" + operacion1 + "<br\>");
var operacion2 = 40 << 2;
document.write("40 x 4 =" + operacion2 + "</br>");
var operacion3 = 25 >> 1;
document.write("25 / 2 =" + operacion3 + "</br>");
var operacion4 = 10 << 4;
document.write("10 x 16 =" + operacion4 + "</br>");