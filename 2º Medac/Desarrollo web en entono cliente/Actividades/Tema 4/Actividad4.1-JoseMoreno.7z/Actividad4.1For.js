for (let i = 1; i <= 10; i++) {
    const numero = 8;
    const operacion = `${numero} + ${i}`;
    const resultado = numero + i;
    document.write(`${operacion} = ${resultado} </br>
    `);
}